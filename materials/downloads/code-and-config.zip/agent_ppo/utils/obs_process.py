import torch

def obs_convert(obs, critic_obs=None):
    # obs
    base_lin_vel = obs[:, 0:3]
    base_ang_vel = obs[:, 3:6]
    projected_gravity = obs[:, 6:9]
    commands = obs[:, 9:12]
    dof_pos = obs[:, 12:24]
    dof_vel = obs[:, 24:36]
    actions = obs[:, 36:48]
    
    if critic_obs is not None:
        # critic_obs
        contact_flag = critic_obs[:, 0:8]
        contact_force = critic_obs[:, 8:20]
        randomize_params = critic_obs[:, 20:24]
        heights = critic_obs[:,72:]

    HIM_obs = torch.cat(
        (
            commands,
            base_ang_vel,
            projected_gravity,
            dof_pos,
            dof_vel,
            actions,
        ),
        dim=-1,
    )   
    
    if critic_obs is not None:
        HIM_critic_obs = torch.cat(
            (
                HIM_obs,
                base_lin_vel,
                randomize_params,
                heights,
            ),
            dim=-1,
        )
    else:
        HIM_critic_obs = None
        
    return HIM_obs, HIM_critic_obs