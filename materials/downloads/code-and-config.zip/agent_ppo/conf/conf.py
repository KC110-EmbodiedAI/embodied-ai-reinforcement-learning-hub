#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2025 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors
"""


class Config:
    class Env:
        # Model saving settings
        MODEL_SAVE_INTERVAL = 500
        # Environment interaction settings
        # 环境交互设置
        NUM_STEPS_PER_ENV = 100 # 从24改为100
        
        num_one_step_observations = 45
        num_history_length = 6
        num_observations = num_one_step_observations * num_history_length
        num_one_step_privileged_obs = 45 + 3 + 4 + 187 # additional: base_lin_vel, randomize_params, scan_dots
        num_privileged_obs = num_one_step_privileged_obs * 1 # if not None a priviledge_obs_buf will be returned by step() (critic obs for assymetric training). None is returned otherwise 
        num_actions = 12
        
    
    class Policy:
        value_loss_coef = 1.0
        use_clipped_value_loss = True
        clip_param = 0.2
        entropy_coef = 0.01
        num_learning_epochs = 5
        num_mini_batches = 4 # mini batch size = num_envs*nsteps / nminibatches
        learning_rate = 5.e-4 #1.e-3 or 5.e-4
        encoder_learning_rate = 5.e-4
        schedule = 'adaptive' # could be adaptive, fixed
        gamma = 0.99
        lam = 0.95
        desired_kl = 0.01
        max_grad_norm = 1.
    
    class Network:
        actor_hidden_dims = [512, 256, 128]
        critic_hidden_dims = [512, 256, 128]
        activation = 'elu'
        init_noise_std = 1.0