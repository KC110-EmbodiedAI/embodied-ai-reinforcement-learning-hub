#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2025 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors
"""


import torch
import torch.optim as optim
import time
from collections import deque, defaultdict
import statistics
import os
from tools.metrics_utils import get_training_metrics
from tools.utils import calculate_terrain_stats

from kaiwu_agent.agent.base_agent import (
    predict_wrapper,
    exploit_wrapper,
    learn_wrapper,
    save_model_wrapper,
    load_model_wrapper,
    BaseAgent,
)

from kaiwu_agent.utils.common_func import attached
from agent_ppo.feature.definition import *
from agent_ppo.conf.conf import Config
from agent_ppo.algorithm.algorithm import Algorithm
from tools.train_env_conf_validate import read_usr_conf, check_usr_conf

from agent_ppo.model import HIMActorCritic
from agent_ppo.utils import obs_convert
from agent_ppo.feature.definition import HIMRolloutStorage

@attached
class Agent(BaseAgent):
    def __init__(self, agent_type="player", device="cuda", logger=None, monitor=None):
        super().__init__(device, logger, monitor)
        
        self.cur_model_name = "ActorCritic"
        self.device = device
        self.logger = logger

        usr_conf = read_usr_conf("agent_ppo/conf/train_env_conf.toml", self.logger)
        if usr_conf is None:
            self.logger.error(f"usr_conf is None, please check agent_ppo/conf/train_env_conf.toml")
            raise Exception(f"usr_conf is None, please check agent_ppo/conf/train_env_conf.toml")

        valid, message = check_usr_conf(usr_conf, False, self.logger)
        if not valid:
            self.logger.error(
                f"check_usr_conf is {valid}, message is {message}, please check agent_ppo/conf/train_env_conf.toml"
            )
            raise Exception(
                f"check_usr_conf is {valid}, message is {message}, please check agent_ppo/conf/train_env_conf.toml"
            )

        self.num_envs = usr_conf["env"]["num_envs"] # Algo-Sample

        self.num_actor_obs = Config.Env.num_observations
        self.num_obs = Config.Env.num_observations
        self.num_critic_obs = Config.Env.num_privileged_obs
        self.num_one_step_obs = Config.Env.num_one_step_observations
        self.num_actions = Config.Env.num_actions
        self.num_privileged_obs = Config.Env.num_privileged_obs
        

        self.actor_hidden_dims = Config.Network.actor_hidden_dims
        self.critic_hidden_dims = Config.Network.critic_hidden_dims
        self.activation = Config.Network.activation
        self.init_noise_std = Config.Network.init_noise_std
        
        # Create Model and convert the model to a channel-last memory format to achieve better performance.
        # 创建模型, 将模型转换为通道后内存格式，以获得更好的性能。
        self.model = HIMActorCritic(
            num_actor_obs=self.num_actor_obs,
            num_critic_obs=self.num_critic_obs,
            num_one_step_obs=self.num_one_step_obs,
            num_actions=self.num_actions,
            
            actor_hidden_dims=self.actor_hidden_dims,
            critic_hidden_dims=self.critic_hidden_dims,
            activation=self.activation,
            init_noise_std=self.init_noise_std,
        ).to(self.device)

        self.logger.info(f"Actor MLP: {self.model.actor}")
        self.logger.info(f"Critic MLP: {self.model.critic}")
        params = [{"params": self.model.parameters(), "name": "actor_critic"}]

        # env info
        # 环境信息
        self.game_id = None

        self.train_count = 0
        self.predict_count = 0

        # tools
        # 工具
        self.reward_manager = None
        self.monitor = monitor
        self.algorithm = Algorithm(self.model, device=self.device, logger=self.logger, monitor=self.monitor)
        
        self.num_steps_per_env = Config.Env.NUM_STEPS_PER_ENV
        self.save_interval = Config.Env.MODEL_SAVE_INTERVAL

        # init storage and model
        # 初始化样本池
        self.algorithm.init_storage(
            self.num_envs, self.num_steps_per_env, 
            [self.num_obs], [self.num_privileged_obs], 
            [self.num_actions]
        )

        # 初始化termination信息维护
        # 用于跟踪哪些环境实例已经终止
        self.termination_ids = torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        # 用于存储终止时的特权观测信息
        self.termination_privileged_obs = torch.zeros(self.num_privileged_obs, device=self.device)


    def update_termination_info(self, dones, privileged_obs):
        """
        更新termination信息
        当环境实例终止时，记录终止时的特权观测信息
        """
        # 找到新终止的环境实例
        new_terminations = dones & (~self.termination_ids)
        
        if new_terminations.any():
            # 更新termination_ids
            self.termination_ids = dones.clone()
            
            # 对于新终止的环境实例，保存其特权观测信息
            # 这里我们取第一个终止实例的特权观测作为代表
            terminated_indices = new_terminations.nonzero(as_tuple=False).flatten()
            if len(terminated_indices) > 0:
                first_terminated_idx = terminated_indices[0]
                self.termination_privileged_obs = privileged_obs[first_terminated_idx].clone().detach()
        
        return self.termination_ids, self.termination_privileged_obs

    def train_workflow(self, env, usr_conf):
        """
        训练工作流程，从him_on_policy_runner.py移植而来
        """
        data, extra_info = env.reset(usr_conf=usr_conf)
        if extra_info.result_code != 0:
            error_message = f"reset failed, result is {extra_info.result_message}"
            self.logger.error(error_message)
            raise Exception(error_message)
        # 初始化观测
        # 因为obs在HIM为45*6，即6个历史步作为观测输入
        obs = torch.zeros(
            size=(self.num_envs, self.num_obs),
            device=self.device,
        )

        # 环境返回的origin_obs为48维，privileged_obs为259维，需要进行转换
        (origin_obs, origin_privileged_obs) = data
        # 返回的obs_single维45维，privileged_obs维45+3+189维
        obs_single, privileged_obs = obs_convert(origin_obs, origin_privileged_obs)
        
        # obs为45*6维，截除最后45维
        obs = torch.cat((obs_single, obs[:, :-self.num_one_step_obs]), dim=-1)
        critic_obs = privileged_obs if privileged_obs is not None else obs
        obs, critic_obs = obs.to(self.device), critic_obs.to(self.device)

        self.algorithm.actor_critic.train() # switch to train mode (for dropout for example)

        ep_infos = []
        rewbuffer = deque(maxlen=100)
        lenbuffer = deque(maxlen=100)
        cur_reward_sum = torch.zeros(self.num_envs, dtype=torch.float, device=self.device)
        cur_episode_length = torch.zeros(self.num_envs, dtype=torch.float, device=self.device)

        last_report_monitor_time = 0
        # Main Training Loop
        # 主训练循环
        episode = 0
        while True:
            self.logger.info(f"Episode {episode} start, usr_conf is {usr_conf}")
            start = time.time()
            
            # Phase 1: Data Collection
            # 阶段1：数据收集
            with torch.inference_mode():
                for i in range(self.num_steps_per_env):
                    # 动作生成
                    actions = self.algorithm.act(obs, critic_obs)

                    command_actions = torch.clip(actions, -6.0, 6.0).to(self.device)
                    if i == 0:
                        self.logger.info(f"clipped_action:{command_actions}")
                    
                    # 环境交互
                    data, extra_info = env.step(command=command_actions)
                    if extra_info.result_code != 0:
                        error_message = f"step failed, result is {extra_info.result_message}"
                        self.logger.error(error_message)
                        raise Exception(error_message)
                    
                    frame_no, origin_obs, rewards, terminated, truncated, (infos, origin_privileged_obs) = data
                    if origin_obs is None:
                        self.logger.info(f"episode {episode}, is None happened!")
                        break
                    dones = torch.logical_or(terminated, truncated)
                    
                    # 更新观测信息
                    obs_single, privileged_obs = obs_convert(origin_obs, origin_privileged_obs)
                    obs = torch.cat((obs_single, obs[:, :-self.num_one_step_obs]), dim=-1)
                    obs = obs.to(self.device)
                    privileged_obs = privileged_obs.to(self.device)
                    critic_obs = privileged_obs if privileged_obs is not None else obs
                    rewards, dones = rewards.to(self.device), dones.to(self.device)
                    
                    # 更新termination信息
                    termination_ids, termination_privileged_obs = self.update_termination_info(dones, privileged_obs)

                    # 构建next_critic_obs，这是HIM算法的关键部分
                    next_critic_obs = critic_obs.clone().detach()
                    if termination_ids.any():
                        # 对于终止的环境实例，使用终止时的特权观测信息
                        next_critic_obs[termination_ids] = termination_privileged_obs.clone().detach()

                    self.algorithm.process_env_step(rewards, dones, infos, next_critic_obs)
                
                    # Book keeping
                    if 'episode' in infos:
                        ep_infos.append(infos['episode'])
                    cur_reward_sum += rewards
                    cur_episode_length += 1
                    new_ids = (dones > 0).nonzero(as_tuple=False)
                    rewbuffer.extend(cur_reward_sum[new_ids][:, 0].cpu().numpy().tolist())
                    lenbuffer.extend(cur_episode_length[new_ids][:, 0].cpu().numpy().tolist())
                    cur_reward_sum[new_ids] = 0
                    cur_episode_length[new_ids] = 0

                stop = time.time()
                collection_time = stop - start

                # Learning step
                start = stop
                self.algorithm.compute_returns(critic_obs)
                
            storage = HIMRolloutStorage(self.num_envs, self.num_steps_per_env, [self.num_obs], [self.num_privileged_obs], [self.num_actions], self.device)
            generator = storage.mini_batch_generator(self.algorithm.num_mini_batches, self.algorithm.num_learning_epochs)
            batch_data = []
            for mini_batch in generator:
                batch_data.append(mini_batch)
            
            episode += 1    
            
            self.algorithm.storage.clear()
            
            # Phase 2: Policy Update
            # 阶段2：策略更新
            # mean_value_loss, mean_surrogate_loss, mean_entropy_loss, estimation_loss, swap_loss = self.learn(batch_data)
            self.learn(batch_data)
            stop = time.time()
            learn_time = stop - start
            self.logger.info(f"Episode {episode} end, cost_time is {learn_time} s")

            
            # Phase 3: Monitoring Metrics Processing
            # 阶段3：监控指标处理
            now = time.time()
            if now - last_report_monitor_time >= 60:
                monitor_data = {
                    "actor_predict_succ_cnt": self.predict_count,
                    "episode_cnt": episode,
                    "total_cost_time": learn_time,
                    "sample_production_and_consumption_ratio": 1,
                    "terrain_curriculum": usr_conf["terrain"]["curriculum"],
                    "actor_load_last_model_succ_cnt": self.predict_count,
                    "sample_receive_cnt": episode * self.num_steps_per_env,
                }

                if len(rewbuffer) > 0:
                    monitor_data["reward"] = statistics.mean(rewbuffer)
                
                if len(lenbuffer) > 0:
                    monitor_data["diy_3"] = statistics.mean(lenbuffer)
                    monitor_data["diy_4"] = self.algorithm.learning_rate * 1e+5

                reward_keys = [
                    "rew_tracking_ang_vel",
                    "rew_tracking_lin_vel",
                    "rew_torques",
                    "max_command_x",
                    "rew_feet_air_time",
                    "rew_action_rate",
                    "rew_ang_vel_xy",
                    "rew_collision",
                    "rew_dof_acc",
                    "rew_dof_pos_limits",
                    "rew_lin_vel_z",
                ]

                if len(ep_infos) > 0:
                    terrain_data = {"stability": [], "success": [], "velocity": [], "level": [], "types": []}

                    generic_metrics = defaultdict(list)

                    terrain_level_values = []

                    for ep_info in ep_infos:
                        for key in ["episode_stability", "episode_success", "episode_velocity"]:
                            if key in ep_info:
                                tensor = (
                                    ep_info[key]
                                    if isinstance(ep_info[key], torch.Tensor)
                                    else torch.tensor(ep_info[key], device=self.device)
                                )
                                terrain_data[key.split("_")[-1]].append(tensor)

                        if "terrain_level" in ep_info:
                            terrain_data["level"].append(ep_info["terrain_level"])
                            terrain_level_values.append(torch.mean(ep_info["terrain_level"].float()))

                        if "terrain_types" in ep_info:
                            terrain_data["types"].append(ep_info["terrain_types"])

                        for key in reward_keys:
                            if key in ep_info:
                                metric = ep_info[key]
                                if not isinstance(metric, torch.Tensor):
                                    metric = torch.tensor(metric, device=self.device)
                                processed_metric = metric.float().mean()
                            else:
                                processed_metric = torch.tensor(0.0, device=self.device, dtype=torch.float32)

                            generic_metrics[key].append(processed_metric)

                    if terrain_level_values:
                        monitor_data["terrain_level"] = torch.mean(torch.stack(terrain_level_values)).item()
                    else:
                        monitor_data["terrain_level"] = 0

                    if all(len(v) > 0 for v in terrain_data.values()):
                        combined = {
                            k: v[-1]
                            for k, v in terrain_data.items()
                            if k in ["stability", "success", "velocity", "level", "types"]
                        }

                        terrain_stats = calculate_terrain_stats(
                            episode_stability=combined["stability"],
                            episode_success=combined["success"],
                            episode_velocity=combined["velocity"],
                            terrain_level=combined["level"],
                            terrain_types=combined["types"],
                            usr_conf=usr_conf,
                        )

                        for stat_key, stat_value in terrain_stats.items():
                            monitor_data[stat_key] = stat_value

                    for metric_key, values in generic_metrics.items():
                        if values:
                            monitor_data[metric_key] = torch.stack(values).mean().item()
                        else:
                            monitor_data[metric_key] = 0.0

                    monitor_data["episode_reward"] = 0.0
                    for key in reward_keys:
                        monitor_data["episode_reward"] += monitor_data.get(key, 0)

                self.monitor.put_data({os.getpid(): monitor_data})
                last_report_monitor_time = now

            training_metrics = get_training_metrics()
            if training_metrics:
                for key, value in training_metrics.items():
                    if key == "env":
                        for env_key, env_value in value.items():
                            self.logger.info(f"training_metrics {key} {env_key} is {env_value}")
                    else:
                        self.logger.info(f"training_metrics {key} is {value}")

            ep_infos.clear()
            
            # Phase 4: Model Saving
            # 阶段4：模型保存
            if episode % Config.Env.MODEL_SAVE_INTERVAL == 0:
                self.save_model(id=episode)
            
        # Close environment
        # 关闭环境
        env.close()

    @predict_wrapper
    def predict(self, list_obs_data):
        (obs, critic_obs) = list_obs_data
        with torch.no_grad():
            (
                actions,
                values,
                actions_log_prob,
                action_mean,
                action_sigma,
                observations,
                critic_observations,
            ) = self.algorithm.act_(obs, critic_obs)

        return [ActData(action=actions)]

    @exploit_wrapper
    def exploit(self, list_obs_data):

        (obs) = list_obs_data
        obs[:, 9] = -1.85 * 2.0
        obs[:, 10] = 0.0
        obs[:, 11] = 0.0
        
        obs_single,_ = obs_convert(obs)
        if hasattr(self, 'obs_history'):
            self.obs_history = torch.cat((obs_single, self.obs_history[:, :-self.num_one_step_obs]), dim=-1)
        else:
            self.obs_history = torch.zeros(
                size=(obs.shape[0], self.num_obs),
                device=self.device,
            )
            self.obs_history = torch.cat((obs_single, self.obs_history[:, :-self.num_one_step_obs]), dim=-1)
            
        with torch.no_grad():
            actions = self.algorithm.actor_critic.act_inference(self.obs_history)

        return [ActData(action=actions)]

    @learn_wrapper
    def learn(self, list_sample_data=None):
        self.train_count += 1
        return self.algorithm.learn()

    def predict_local(self, obs, critic_obs):
        """
        local predict
        本地预测
        """
        self.predict_count += 1
        return self.algorithm.act_(obs, critic_obs)

    def action_process(self, act_data):
        pass

    def observation_process(self, obs_q):
        pass

    def reset(self):
        pass

    @save_model_wrapper
    def save_model(self, path=None, id="1"):
        """
        To save the model, it can consist of multiple files, and it is important to ensure that
        each filename includes the "model.ckpt-id" field.
        保存模型, 可以是多个文件, 需要确保每个文件名里包括了model.ckpt-id字段
        """
        model_file_path = f"{path}/model.ckpt-{str(id)}.pkl"
        torch.save(self.model.state_dict(), model_file_path)
        self.logger.info(f"save model {model_file_path} successfully")

    @load_model_wrapper
    def load_model(self, path=None, id="1"):
        """
        When loading the model, you can load multiple files, and it is important to ensure that
        each filename matches the one used during the save_model process.
        加载模型, 可以加载多个文件, 注意每个文件名需要和save_model时保持一致
        """
        model_file_path = f"{path}/model.ckpt-{str(id)}.pkl"
        if self.cur_model_name == model_file_path:
            self.logger.info(f"current model is {model_file_path}, so skip load model")
        else:
            self.model.load_state_dict(
                torch.load(
                    model_file_path,
                    map_location=self.device,
                )
            )
            self.cur_model_name = model_file_path
            self.logger.info(f"load model {model_file_path} successfully")
