#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2025 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors
"""
import torch
from isaacgym.torch_utils import *

def _reward_remove_dist_limit(env):
    contact_termination = torch.any(
        torch.norm(env.contact_forces[:, env.termination_contact_indices, :], dim=-1) > 1.0, 
        dim=1
    )
    attitude_termination = torch.logical_or(
        torch.abs(env.rpy[:, 1]) > 1.0, 
        torch.abs(env.rpy[:, 0]) > 0.8
    )
    timeout_termination = env.time_out_buf
    env.reset_buf[:] = contact_termination | attitude_termination | timeout_termination
    return torch.zeros(env.num_envs, device=env.device, dtype=torch.float)
    

def _reward_term_success(self):
    device = self.reset_buf.device

    term_now = self.reset_buf & (~self.time_out_buf)

    distance = torch.norm(self.root_states[:, :2] - self.env_origins[:, :2], dim=1)
    success = distance > (self.terrain.env_length / 2)

    mask = term_now & success
    if not torch.any(mask):
        return torch.zeros_like(self.reset_buf, dtype=torch.float32, device=device)

    steps = self.episode_length_buf.clamp(min=1)

    total_return = torch.zeros_like(steps, dtype=torch.float32)
    for name, buf in self.episode_sums.items():
        if name == "term_success":
            continue
        total_return = total_return + buf

    avg_step_reward = total_return / steps  # shape: [num_envs]

    max_steps = self.max_episode_length
    remaining_steps = (max_steps - steps).clamp(min=0)

    bonus = avg_step_reward * remaining_steps  # shape: [num_envs]

    out = torch.zeros_like(bonus)
    out[mask] = bonus[mask]

    return out


def _reward_term_failure(self):
    """
    在 episode 终止且非 timeout 的当步：
    - 若未达成“成功”条件 -> 返回 1
    - 否则 -> 返回 0
    """
    term_now = self.reset_buf & (~self.time_out_buf)
    distance = torch.norm(self.root_states[:, :2] - self.env_origins[:, :2], dim=1)
    success = distance > (self.terrain.env_length / 2)
    failure = term_now & (~success)
    return failure.float()

def _reward_term_timeout(self):
    return (self.reset_buf & self.time_out_buf).float()



#------------ reward functions in HIMLocomotion 22 ----------------
def _reward_HIM_tracking_lin_vel(self):
    # Tracking of linear velocity commands (xy axes)
    lin_vel_error = torch.sum(torch.square(self.commands[:, :2] - self.base_lin_vel[:, :2]), dim=1)
    return torch.exp(-lin_vel_error/self.cfg.rewards.tracking_sigma)

def _reward_HIM_tracking_ang_vel(self):
    # Tracking of angular velocity commands (yaw) 
    ang_vel_error = torch.square(self.commands[:, 2] - self.base_ang_vel[:, 2])
    return torch.exp(-ang_vel_error/self.cfg.rewards.tracking_sigma)

def _reward_HIM_lin_vel_z(self):
    # Penalize z axis base linear velocity
    return torch.square(self.base_lin_vel[:, 2])

def _reward_HIM_ang_vel_xy(self):
    # Penalize xy axes base angular velocity
    return torch.sum(torch.square(self.base_ang_vel[:, :2]), dim=1)

def _reward_HIM_orientation(self):
    # Penalize non flat base orientation
    return torch.sum(torch.square(self.projected_gravity[:, :2]), dim=1)

def _reward_HIM_dof_acc(self):
    # Penalize dof accelerations
    return torch.sum(torch.square((self.last_dof_vel - self.dof_vel) / self.dt), dim=1)

def _reward_HIM_joint_power(self):
    #Penalize high power
    return torch.sum(torch.abs(self.dof_vel) * torch.abs(self.torques), dim=1)

def _reward_HIM_base_height(self):
    def quat_apply_yaw(quat, vec):
        from isaacgym.torch_utils import quat_apply, normalize
        
        quat_yaw = quat.clone().view(-1, 4)
        quat_yaw[:, :2] = 0.
        quat_yaw = normalize(quat_yaw)
        return quat_apply(quat_yaw, vec)
    
    # Penalize base height away from target
    if self.cfg.terrain.mesh_type == 'plane':
        return self.root_states[:, 2].clone()
    elif self.cfg.terrain.mesh_type == 'none':
        raise NameError("Can't measure height with terrain mesh type 'none'")

    if not hasattr(self, 'num_base_height_points'):
        y = torch.tensor([-0.2, -0.15, -0.1, -0.05, 0., 0.05, 0.1, 0.15, 0.2], device=self.device, requires_grad=False)
        x = torch.tensor([-0.15, -0.1, -0.05, 0., 0.05, 0.1, 0.15], device=self.device, requires_grad=False)
        grid_x, grid_y = torch.meshgrid(x, y)

        self.num_base_height_points = grid_x.numel()
        base_height_points = torch.zeros(self.num_envs, self.num_base_height_points, 3, device=self.device, requires_grad=False)
        base_height_points[:, :, 0] = grid_x.flatten()
        base_height_points[:, :, 1] = grid_y.flatten()
        self.base_height_points = base_height_points
        
    points = quat_apply_yaw(self.base_quat.repeat(1, self.num_base_height_points), self.base_height_points) + (self.root_states[:, :3]).unsqueeze(1)

    points += self.terrain.cfg.border_size
    points = (points/self.terrain.cfg.horizontal_scale).long()
    px = points[:, :, 0].view(-1)
    py = points[:, :, 1].view(-1)
    px = torch.clip(px, 0, self.height_samples.shape[0]-2)
    py = torch.clip(py, 0, self.height_samples.shape[1]-2)

    heights1 = self.height_samples[px, py]
    heights2 = self.height_samples[px+1, py]
    heights3 = self.height_samples[px, py+1]
    heights = torch.min(heights1, heights2)
    heights = torch.min(heights, heights3)
    # heights = (heights1 + heights2 + heights3) / 3

    base_height =  heights.view(self.num_envs, -1) * self.terrain.cfg.vertical_scale
    base_height = torch.mean(self.root_states[:, 2].unsqueeze(1) - base_height, dim=1)

    return torch.square(base_height - self.cfg.rewards.base_height_target)

def _reward_HIM_foot_clearance(self):
    self.feet_pos = self.rigid_body_states.view(self.num_envs, self.num_bodies, 13)[:, self.feet_indices, 0:3]
    self.feet_vel = self.rigid_body_states.view(self.num_envs, self.num_bodies, 13)[:, self.feet_indices, 7:10]

    cur_footpos_translated = self.feet_pos - self.root_states[:, 0:3].unsqueeze(1)
    footpos_in_body_frame = torch.zeros(self.num_envs, len(self.feet_indices), 3, device=self.device)
    cur_footvel_translated = self.feet_vel - self.root_states[:, 7:10].unsqueeze(1)
    footvel_in_body_frame = torch.zeros(self.num_envs, len(self.feet_indices), 3, device=self.device)
    for i in range(len(self.feet_indices)):
        footpos_in_body_frame[:, i, :] = quat_rotate_inverse(self.base_quat, cur_footpos_translated[:, i, :])
        footvel_in_body_frame[:, i, :] = quat_rotate_inverse(self.base_quat, cur_footvel_translated[:, i, :])
    
    height_error = torch.square(footpos_in_body_frame[:, :, 2] - self.cfg.rewards.clearance_height_target).view(self.num_envs, -1)
    foot_leteral_vel = torch.sqrt(torch.sum(torch.square(footvel_in_body_frame[:, :, :2]), dim=2)).view(self.num_envs, -1)
    return torch.sum(height_error * foot_leteral_vel, dim=1)

def _reward_HIM_action_rate(self):
    # Penalize changes in actions
    return torch.sum(torch.square(self.last_actions - self.actions), dim=1)

def _reward_HIM_smoothness(self):
    # second order smoothness
    if not hasattr(self, 'last_last_actions'):
        self.last_last_actions = torch.zeros(self.num_envs, self.num_actions, device=self.device)
    
    smoothness = torch.sum(torch.square(self.actions - self.last_actions - self.last_actions + self.last_last_actions), dim=1)
    self.last_last_actions[:] = self.last_actions[:]
    return smoothness

def _reward_HIM_torques(self):
    # Penalize torques
    return torch.sum(torch.square(self.torques), dim=1)

def _reward_HIM_dof_vel(self):
    # Penalize dof velocities
    return torch.sum(torch.square(self.dof_vel), dim=1)

def _reward_HIM_collision(self):
    # Penalize collisions on selected bodies
    return torch.sum(1.*(torch.norm(self.contact_forces[:, self.penalised_contact_indices, :], dim=-1) > 0.1), dim=1)

def _reward_HIM_termination(self):
    # Terminal reward / penalty
    return self.reset_buf * ~self.time_out_buf

def _reward_HIM_dof_pos_limits(self):
    # Penalize dof positions too close to the limit
    out_of_limits = -(self.dof_pos - self.dof_pos_limits[:, 0]).clip(max=0.) # lower limit
    out_of_limits += (self.dof_pos - self.dof_pos_limits[:, 1]).clip(min=0.)
    return torch.sum(out_of_limits, dim=1)

def _reward_HIM_dof_vel_limits(self):
    # Penalize dof velocities too close to the limit
    # clip to max error = 1 rad/s per joint to avoid huge penalties
    return torch.sum((torch.abs(self.dof_vel) - self.dof_vel_limits*self.cfg.rewards.soft_dof_vel_limit).clip(min=0., max=1.), dim=1)

def _reward_HIM_torque_limits(self):
    # penalize torques too close to the limit
    return torch.sum((torch.abs(self.torques) - self.torque_limits*self.cfg.rewards.soft_torque_limit).clip(min=0.), dim=1)

def _reward_HIM_feet_air_time(self):
    # Reward long steps
    # Need to filter the contacts because the contact reporting of PhysX is unreliable on meshes
    contact = self.contact_forces[:, self.feet_indices, 2] > 1.
    contact_filt = torch.logical_or(contact, self.last_contacts) 
    self.last_contacts = contact
    first_contact = (self.feet_air_time > 0.) * contact_filt
    self.feet_air_time += self.dt
    rew_airTime = torch.sum((self.feet_air_time - 0.5) * first_contact, dim=1) # reward only on first contact with the ground
    rew_airTime *= torch.norm(self.commands[:, :2], dim=1) > 0.1 #no reward for zero command
    self.feet_air_time *= ~contact_filt
    return rew_airTime

def _reward_HIM_stumble(self):
    # Penalize feet hitting vertical surfaces
    return torch.any(torch.norm(self.contact_forces[:, self.feet_indices, :2], dim=2) >\
            5 *torch.abs(self.contact_forces[:, self.feet_indices, 2]), dim=1)
    
def _reward_HIM_stand_still(self):
    # Penalize motion at zero commands
    return torch.sum(torch.abs(self.dof_pos - self.default_dof_pos), dim=1) * (torch.norm(self.commands[:, :2], dim=1) < 0.1)

def _reward_HIM_feet_contact_forces(self):
    # penalize high contact forces
    return torch.sum((torch.norm(self.contact_forces[:, self.feet_indices, :], dim=-1) -  self.cfg.rewards.max_contact_force).clip(min=0.), dim=1)


#------------ reward functions in WalkTheseWays ----------------
def _reward_WTW_feet_slip(env):
    foot_vel = env.rigid_body_lin_vel[:, env.feet_indices, :]

    contact_buf_name = 'last_contacts_buffer' # 改个名字防止和内部变量冲突
    if not hasattr(env, contact_buf_name):
        num_feet = len(env.feet_indices)
        setattr(env, contact_buf_name, torch.zeros(env.num_envs, num_feet, dtype=torch.bool, device=env.device))
    
    last_contacts = getattr(env, contact_buf_name)

    contact = env.contact_forces[:, env.feet_indices, 2] > 1.0

    contact_filt = torch.logical_or(contact, last_contacts)

    last_contacts[:] = contact

    foot_velocities_sq = torch.square(torch.norm(foot_vel[:, :, 0:2], dim=2).view(env.num_envs, -1))
    
    rew_slip = torch.sum(contact_filt * foot_velocities_sq, dim=1)
    return rew_slip


def _reward_WTW_feet_contact_vel(env):
    foot_pos_z = env.rigid_body_pos[:, env.feet_indices, 2]

    foot_vel = env.rigid_body_lin_vel[:, env.feet_indices, :]

    reference_heights = 0.0 

    near_ground = (foot_pos_z - reference_heights) < 0.03

    foot_velocities_sq = torch.square(torch.norm(foot_vel, dim=2).view(env.num_envs, -1))
    
    rew_contact_vel = torch.sum(near_ground * foot_velocities_sq, dim=1)
    return rew_contact_vel


def _reward_WTW_feet_contact_forces(env):
    max_force = getattr(env.cfg.rewards, 'max_contact_force', 500.0) 

    foot_forces = torch.norm(env.contact_forces[:, env.feet_indices, :], dim=-1)

    return torch.sum((foot_forces - max_force).clip(min=0.), dim=1)


### Stand Width
import torch
from isaacgym.torch_utils import quat_rotate_inverse, quat_conjugate

def _reward_WTW_stance_width(env):
    if hasattr(env, 'foot_positions'):
        foot_pos = env.foot_positions
    else:
        # shape: (num_envs, num_bodies, 3) -> (num_envs, 4, 3)
        foot_pos = env.rigid_body_pos[:, env.feet_indices, :]

    target_stance_width = self.cfg.rewards.clearance_height_target # 目标站宽 (米)
    target_y_abs = target_stance_width / 2.0

    # env.base_pos shape: (num_envs, 3) -> unsqueeze -> (num_envs, 1, 3)
    foot_pos_local = foot_pos - env.base_pos.unsqueeze(1)
    
    feet_y_errors = []
    
    inv_base_quat = quat_conjugate(env.base_quat)
    
    for i in range(4):
        foot_vec = foot_pos_local[:, i, :]
        
        foot_local_body = quat_rotate_inverse(env.base_quat, foot_vec)

        y_pos = foot_local_body[:, 1]

        error = torch.abs(y_pos) - target_y_abs
        feet_y_errors.append(torch.square(error))

    total_error = torch.stack(feet_y_errors, dim=1).sum(dim=1)
    
    return total_error


# self
def _reward_hip_angle(env):
    # [FL_hip, FL_thigh, FL_calf, FR_hip, FR_thigh, FR_calf, ...]
    hip_indices = [0, 3, 6, 9]
    
    delta = env.dof_pos[:, hip_indices] - env.default_dof_pos[:, hip_indices]
    
    return torch.sum(torch.square(delta), dim=1)